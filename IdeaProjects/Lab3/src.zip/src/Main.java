import java.util.Scanner;

public class Main {
    public static void main(String args[]){
        int mpg;
        double capacity;
        double gasPercent;
        Scanner scanner = new Scanner(System.in);


        System.out.print("Enter your car's MPG rating (miles/gallon) as a positive integer: ");
        mpg = scanner.nextInt();
        if (mpg <= 0){
            System.out.println("ERROR: ONLY POSITIVE INTEGERS ACCEPTED FOR MPG!!!");
            System.exit(0);
        }
        System.out.print("Enter your car's tank capacity (gallons) as a positive decimal number: ");
        capacity = scanner.nextDouble();
        if (capacity <= 0){
            System.out.println("ERROR: ONLY POSITIVE DECIMAL NUMBERS ACCEPTED FOR TANK CAPACITY!!!");
            System.exit(0);
        }
        System.out.print("Enter the percentage of the gas tank that is currently filled (from 0-100%): ");
        gasPercent = scanner.nextDouble();
        if (gasPercent < 0 || gasPercent > 100) {
            System.out.println("ERROR: PERCENTAGE MUST BE A DECIMAL NUMBER IN THE RANGE OF 0-100(INCLUSIVE)!!!");
            System.exit(0);
        }
        double range = ((mpg * (capacity* (gasPercent*0.01))));
        Math.floor(range);
        if(range <= 25) {
            System.out.println("Attention! Your current estimated range is running low: " + (int) range + " left!!!");
        }
        else{
            System.out.println("Keep driving! Your current estimated range is: " + (int) range + " miles!");
        }
    }
}
